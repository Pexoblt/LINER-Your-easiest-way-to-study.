LINER — aplicație desktop pentru concentrare, timer și calendar.

Interfață disponibilă în română și engleză.
Datele calendarului, preferințele timerului și limba sunt păstrate local în profilul aplicației.

Pentru instalare: rulează build_windows.bat pe Windows cu Node.js instalat.


La prima pornire, LINER afișează un mini-setup animat pentru nume, limbă și vârstă. Preferințele sunt salvate local pe dispozitiv. Credite: Created by pexoblt & ASTER.
