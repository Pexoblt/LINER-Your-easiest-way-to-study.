@echo off
setlocal
cd /d "%~dp0"
title Build LINER pentru Windows

 echo.
echo ================================================
echo   LINER - creare aplicatie Windows .EXE
echo ================================================
echo.

where node >nul 2>&1
if errorlevel 1 goto no_node
where npm >nul 2>&1
if errorlevel 1 goto no_npm

echo [1/2] Instalez dependintele necesare...
call npm install
if errorlevel 1 goto failed

echo.
echo [2/2] Construiesc installerul Windows...
call npm run dist:win
if errorlevel 1 goto failed

echo.
echo GATA! Installerul este in folderul dist.
echo Fisier: dist\LINER-Setup-1.1.1.exe
echo.
if exist "dist" start "" "%CD%\dist"
pause
exit /b 0

:no_node
echo Nu gasesc Node.js.
echo Instaleaza Node.js 24 LTS de la https://nodejs.org/en/download/
echo Apoi inchide si redeschide aceasta fereastra si ruleaza din nou build_windows.bat.
pause
exit /b 1

:no_npm
echo Nu gasesc npm. Reinstaleaza Node.js 24 LTS si asigura-te ca optiunea npm este inclusa.
pause
exit /b 1

:failed
echo.
echo Construirea nu a reusit. Citeste mesajul de eroare de mai sus.
echo Verifica si conexiunea la internet, necesara la prima instalare.
pause
exit /b 1
